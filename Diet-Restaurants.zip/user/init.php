<?php

$models = "../models/";
$cont 	= '../controllers/'; 
$func	= '../functions/'; 
$css 	= '../assets/css/'; 
$imgs 	= '../assets/images/'; 
$uploads = "../uploads/";
$inc  = "../incs/";
$app   = '../';


$userroute = '../user/';  
$restaurantsroute = '../restaurants/';  
