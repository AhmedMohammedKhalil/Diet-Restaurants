<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ERORR</title>
</head>
<body>
    <div>
        <h4>Failed To Connect... Make Sure Your Connect with Database is Open</h4>
        <a href="/diet-restaurants/">Go to Home</a>
    </div>
</body>
</html>