<?php

	$models = "../models/";
	$cont 	= '../controllers/'; 
	$css 	= '../assets/css/'; 
    $imgs 	= '../assets/images/'; 
	$inc  = "../incs/";
	$uploads = "../uploads/";
	$app   = '../';


	$restaurantsroute = '../restaurants/';  
	$userroute = '../user/';  
	