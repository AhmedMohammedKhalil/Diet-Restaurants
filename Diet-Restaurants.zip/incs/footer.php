            <footer>
                <p>© 2022 Diet Restaurants All Right Reserved</p>
            </footer>
        </section>
    </body>
</html>