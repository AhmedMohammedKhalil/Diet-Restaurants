<section id="container">
    <div id="main-content">
        <div class="art-content">
                <div class="form search">
                    <form name="form1"  method="" action="">
                        <div class="flex">
                            <div style="width: 100%;">
                                <input type="search" name="search" id="search" placeholder="Search about restaurants" required="required" style="width: 100%; margin:0"/>
                            </div>
                            <div style="width:40%">
                                <center><input class="submit" type="submit" name="search" value="Search" style="width:100%"></center>
                            </div>
                        </div>
                    </form>
                </div>
        </div>
    </div>
</section>
<hr class="line-1">